package inner;

abstract class Animal {
	abstract void say();
}
