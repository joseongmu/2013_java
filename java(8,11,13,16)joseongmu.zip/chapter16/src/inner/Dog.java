package inner;

public class Dog extends Animal {

	@Override
	void say() {
		System.out.println("�۸�");
	}

}
