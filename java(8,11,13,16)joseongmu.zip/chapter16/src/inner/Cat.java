package inner;

public class Cat extends Animal {

	@Override
	void say() {
		System.out.println("�߿�");
	}

}
